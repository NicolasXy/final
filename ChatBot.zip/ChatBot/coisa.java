import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class coisa extends JFrame{
    JTextArea textarea;
    JButton button;
    JLabel label;

    public coisa(){
        setLayout(new FlowLayout());

        textarea = new JTextArea( 5, 30);
        add(textarea);

        button = new JButton("Clica ae");
        add(button);

        label = new JLabel("");
        add(label);

        event e = new event();
        button.addActionListener(e);
    }

    public class event implements ActionListener{
        public void actionPerformed(ActionEvent e){
            String text = textarea.getText();
            while(text!=("uai")){
            if (text.equals("aa")){
                label.setText("Opa opa");
                break;
            }
            if (text.equals("bb")){
                label.setText("Ole Ole");
                break;
            } 
            if (text.equals("cc")){
                label.setText("Alo Alo");
                break;
            }
            if (text.equals("dd")){
                label.setText("Ela Ela");
                break;
            }
            if (text.equals("ee")){
                label.setText("Ili Ili");
                break;
            }
            continue;
        } 
                
            

        }
    }


    public static void main(String args[]){
        coisa gui = new coisa();
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setSize(400, 200);
        gui.setVisible(true);
    }

}
