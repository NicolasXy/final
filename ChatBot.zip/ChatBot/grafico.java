public class grafico {
    
}
