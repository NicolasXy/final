

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class tela extends JFrame {
    
    ImageIcon gato = new ImageIcon(getClass().getResource("gato.jpg"));
    JLabel label = new JLabel(gato);

    //////////////////////////////////////////////// configurações da janela
    public tela(){

        add(label);

        setSize(500,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(this);
        setVisible(true);
    }
    public static void main(String[] args){
        //////////////////////////////////////////// chamando a classe de cima
        new tela();
    }
}
