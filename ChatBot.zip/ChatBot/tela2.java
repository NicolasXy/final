import javax.swing.JFrame;

public class tela2 extends JFrame {
    //////////////////////////////////////////////// configurações da janela
    public tela2(){
        setSize(500,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(this);
        setVisible(true);
    }
    public static void main(String[] args){
        //////////////////////////////////////////// chamando a classe de cima
        new tela();
    }
}
