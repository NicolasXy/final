import java.util.Scanner;

public class perguntas {
    public static void main (String[] args){
        Scanner quest = new Scanner(System.in);
        System.out.println(".");
        System.out.println("Olá! Sou Cleitin, um ChatBot! Só lembrando que eu não uso acentuação nem caracteres especiais hein!");
        System.out.println("Deseja conversar um pouco?");
        System.out.println(".");
        String perginicial = quest.nextLine();
        if (perginicial.equals("Sim")){
            System.out.println(".");
            System.out.println("Certo! Digite a senha 'Ola' :D");
            System.out.println(".");
        }

        String perg = quest.nextLine();
        if(perg.equals("Ola")){
            System.out.println(".");
            System.out.println("Olá meu caro! Em que posso te ajudar hoje?");
        }
        while(perg.equals("Ola")){
            String perg2 = quest.nextLine();



            if(perg2.equals ("Como voce esta?")){
                System.out.println(".");
                System.out.println("Estou bem, em que posso te ajudar?");              
            }

            if (perg2.equals("Faca uma conta")){
                System.out.println(".");
                System.out.println("Claro! Vou te ensinar a fazer uma boa conta! Basta apertar a tecla 'Windows', digitar 'calculadora' e resolver seus problemas! :D");
            }

            if (perg2.equals("Que tal um jogo?")){
                System.out.println(".");
                System.out.println("Certo, que os jogos comecem!");
                //////////////////////////////////////////////////////////////////////////////////////
            }

            if (perg2.equals("Canta uma musica")){
                System.out.println(".");
                System.out.println("Dame dane, dame yo, dame nano yo... Anta ga, suki de, suki sugi te...");
            }

            if (perg2.equals("Nada nao")){
                System.out.println(".");
                System.out.println("Tá bom, então tchau!");
                break;
            }

            if (perg2.equals("Conta uma piada")){
                System.out.println(".");
                System.out.println("Beleza, Lá vai!");
                System.out.println("Por que o cadeirante não conseguiu seguir com a vida dele? Porque ele não pôde dar o próximo passo! xD");
                System.out.println(".");
                System.out.println("Quer mais uma?");
                String perg3 = quest.nextLine();

                if (perg3.equals("Sim")){
                    System.out.println(".");
                    System.out.println("O que acontece se uma galinha sem penas cometer um crime? Nada! vai ser um crime sem penalidade! :D");
                } if (perg3.equals("Nao")){
                    System.out.println(".");
                    System.out.println("Tá bom..."); /////////////////////////////////////////
                }
            
            if (perg2.equals("Faz uma rima")){
                System.out.println(".");
                System.out.println("SE VOCÊ CURTIU, SE INSCREVE NO CANAL, TODA TERÇA VÍDEO NOVO, A PARADA É SEMANAL, DÁ UM LIKE E COMPARTILHA PRA PODER CONTINUAR, VOCÊS SÃO MINHA FORÇA, TAMO JUNTO, VAMO LÁ - Tauz");
            }
            }

            if (perg2.equals("Completa minha frase")){
                System.out.println(".");
                System.out.println("Beleza, começa ae");
                String perg3 = quest.nextLine();
                System.out.println(".");
                System.out.println(perg3 + " " + "AAa"); ////////////////////// Random
            }

            if (perg2.equals ("So conversando um pouco")){
                System.out.println(".");
                System.out.println("Beleza, sobre o que você quer conversar então?");
                String perg3 = quest.nextLine();

                if (perg3.equals("Historia")){
                    System.out.println(".");
                    System.out.println("Beleza, sei falar sobre a Revolução Francesa, Brasil Colônia, Segunda Guerra Mundial e Egito Antigo, sobre qual deles você quer falar?");
                } ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            }

            if (perg2.equals("Me fale sobre a economia")){
                System.out.println(".");
                System.out.println("Tá bom, você quer saber onde investir, como juntar dinheiro ou autocontrole?"); ///////////////////////////////
            }

            System.out.println(".");
            System.out.println("Certo! O que mais posso te ajudar?");
        }


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        if (perg.equals("salve")){ ////////////////////////////////////////////////////////////////////
            System.out.println("Salve amiguinho! em que posso te ajudar hoje?");
            String perg2 = quest.nextLine();

            if (perg2.equals ("So conversando um pouco")){
                System.out.println("Beleza, sobre o que você quer conversar então?");
            }

            if(perg2.equals ("Como voce esta?")){
                System.out.println("Estou bem, em que posso te ajudar?");
            }
        }
        
        quest.close();
        } 
}
