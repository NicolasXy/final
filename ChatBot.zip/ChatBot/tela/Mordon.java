package tela;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class Mordon extends JFrame{
    JButton button = new JButton("Enviar");
    JTextArea textarea = new JTextArea();
    JLabel label = new JLabel("Olá! Eu sou Mordon, em que posso te ajudar?");
    Font grande = new Font("Serif", Font.BOLD,20);
    ImageIcon gato = new ImageIcon(getClass().getResource("gato.jpg")); /*** buscando a imagem ***/
    JLabel imgGato = new JLabel(gato);                    /*** colocando a imagem em uma label ***/

    ImageIcon teste = new ImageIcon(getClass().getResource("teste.gif"));
    ImageIcon teste2 = new ImageIcon(getClass().getResource("teste2.gif"));
    JLabel teste1 = new JLabel(teste);
    JLabel tst2 = new JLabel(teste2);
    
    public Mordon(){

        event e = new event();
        button.addActionListener(e);
        
    /********************** Configurando a Tela ************************/


        JFrame tela = new JFrame();
        tela.setTitle("Mordon");
        tela.setSize(560,650);
        tela.setMinimumSize(new Dimension(300,350));
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
        tela.getContentPane().setBackground(Color.darkGray);

    /**************** Configurando o local dos objetos *****************/  
        tela.setLayout(null);
        tela.add(button);                                 /*** botão ***/
        button.setBounds(440,560,70,30);
        tela.add(textarea);                       /*** área de texto ***/
        textarea.setBounds(20,560,400,30);
        tela.add(label);      /*** Espaço onde as respostas aparecem ***/
        label.setBounds(40,0,460,90);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setForeground(Color.white);
        label.setFont(grande);
        tela.add(imgGato);
        imgGato.setBounds(20,90,510,450);

    }

    public class event implements ActionListener{
        public void actionPerformed(ActionEvent e){
            String text = textarea.getText();
            while(text!=("ualeiaiqkj")){
            if (text.equals("como voce esta?")){
                label.setText("Estou bem, em que posso te ajudar?");                
                break;
            }
            if (text.equals("calcule")){
                label.setText("Certo, lá vai!");
                /********************************************************** Linka o Main aqui */
                
                break;
            } 
            if (text.equals("manda uma musica")){
                label.setText("Dame dane, dame yo, dame nano yo... Anta ga, suki de, suki sugi te...");
                break;
            }
            if (text.equals("jogar")){
                label.setText("Certo, se prepare!");
                /********************************************************** Linka o Quiz aqui */
                break;
            }
            if (text.equals("sair")){
                label.setText("Tá bom, então tchau!");
                System.exit(0);
                break;
            }
            if (text.equals("oi")){
                label.setText("qual o preço do dinheiro angolano?");                
                break;
            }
            if (text.equals("bb")){
                label.setText("Ole Ole");
                break;
            } 
            if (text.equals("cc")){
                label.setText("Alo Alo");
                break;
            }
            if (text.equals("dd")){
                label.setText("Salve Salve");
                break;
            }
            if (text.equals("ee")){
                label.setText("Eae Eae");
                break;
            }
            continue;
        } 
        }
    }


    public static void main(String args[]){
        new Mordon();
    }

}
