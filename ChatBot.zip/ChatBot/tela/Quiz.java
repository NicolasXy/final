package tela;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Quiz {
    public static final char[] questao = null;

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        
        String questao = "Quem criou o Java?";

        Collection<String> alternativas = new ArrayList<>();
        alternativas.add("Bill Gates");
        alternativas.add("James Gosling");
        alternativas.add("Steve Jobs");
        alternativas.add("Elon Musk");
        alternativas.add("Jeff Bezos");

        String alternativaCorreta = "James Gosling";
        String alternativaErradaA = "Bill Gates";
        String alternativaErradaB = "Steve Jobs";
        String alternativaErradaC = "Elon Musk";
        String alternativaErradaD = "Jeff Bezos";

        boolean respostaCerta = false;

        do {
        System.out.println(questao);

        //embaralhar as pergunta
        Collections.shuffle((List<String>) alternativas);

        //mostra perguntas
        for(int i = 0; i < alternativas.size(); i++) {
            System.out.println("[" + i + "]" + ((List<String>) alternativas).get(i));
        }

        System.out.println("Digite sua resposta: ");
        String resposta = scanner.nextLine();
        int respostaInt = Integer.parseInt(resposta);

        String valorDaResposta = ((List<String>) alternativas).get(respostaInt);
        
        if ( valorDaResposta.equals(alternativaCorreta)){
            System.out.println("Resposta Correta!");
            respostaCerta = true;

            String questao2 = "De onde é a invenção do chuveiro elétrico?";

            Collection<String> alternativas2 = new ArrayList<>();
            alternativas2.add("França");
            alternativas2.add("Inglaterra");
            alternativas2.add("Brasil");
            alternativas2.add("Austrália");
            alternativas2.add("Itália");
    
            String alternativaCorreta2 = "Brasil";
            String alternativaErradaA2 = "França";
            String alternativaErradaB2 = "Inglaterra";
            String alternativaErradaC2 = "Austrália";
            String alternativaErradaD2 = "Itália";
    
            boolean respostaCerta2 = false;
    
            do {
            System.out.println(questao2);
    
            //embaralhar as pergunta
            Collections.shuffle((List<String>) alternativas2);
    
            //mostra perguntas
            for(int i = 0; i < alternativas2.size(); i++) {
                System.out.println("[" + i + "]" + ((List<String>) alternativas2).get(i));
            }
    
            System.out.println("Digite sua resposta: ");
            String resposta2 = scanner.nextLine();
            int respostaInt2 = Integer.parseInt(resposta2);
    
            String valorDaResposta2 = ((List<String>) alternativas2).get(respostaInt2);
    
            if ( valorDaResposta2.equals(alternativaCorreta2)) {
                System.out.println("Resposta Correta!");
                respostaCerta2 = true;

                String questao3 = "Atualmente, quantos elementos químicos a tabela periódica possui?";

            Collection<String> alternativas3 = new ArrayList<>();
            alternativas3.add("113");
            alternativas3.add("109");
            alternativas3.add("108");
            alternativas3.add("118");
            alternativas3.add("92");
    
            String alternativaCorreta3 = "118";
            String alternativaErradaA3 = "113";
            String alternativaErradaB3 = "109";
            String alternativaErradaC3 = "108";
            String alternativaErradaD3 = "92";
    
            boolean respostaCerta3 = false;
    
            do {
            System.out.println(questao3);
    
            //embaralhar as pergunta
            Collections.shuffle((List<String>) alternativas3);
    
            //mostra perguntas
            for(int i = 0; i < alternativas3.size(); i++) {
                System.out.println("[" + i + "]" + ((List<String>) alternativas3).get(i));
            }
    
            System.out.println("Digite sua resposta: ");
            String resposta3 = scanner.nextLine();
            int respostaInt3 = Integer.parseInt(resposta3);
    
            String valorDaResposta3 = ((List<String>) alternativas3).get(respostaInt3);
    
            if ( valorDaResposta3.equals(alternativaCorreta3)) {
                System.out.println("Resposta Correta!");
                respostaCerta3 = true;

                String questao4 = "Em qual local da Ásia o português é língua oficial?";

            Collection<String> alternativas4 = new ArrayList<>();
            alternativas4.add("Índia");
            alternativas4.add("Filipinas");
            alternativas4.add("Moçambique");
            alternativas4.add("Macau");
            alternativas4.add("Portugal");
    
            String alternativaCorreta4 = "Macau";
            String alternativaErradaA4 = "Portugal";
            String alternativaErradaB4 = "Moçambique";
            String alternativaErradaC4 = "Filipinas";
            String alternativaErradaD4 = "Índia";
    
            boolean respostaCerta4 = false;
    
            do {
            System.out.println(questao4);
    
            //embaralhar as pergunta
            Collections.shuffle((List<String>) alternativas4);
    
            //mostra perguntas
            for(int i = 0; i < alternativas4.size(); i++) {
                System.out.println("[" + i + "]" + ((List<String>) alternativas4).get(i));
            }
    
            System.out.println("Digite sua resposta: ");
            String resposta4 = scanner.nextLine();
            int respostaInt4 = Integer.parseInt(resposta4);
    
            String valorDaResposta4 = ((List<String>) alternativas4).get(respostaInt4);
    
            if ( valorDaResposta4.equals(alternativaCorreta4)) {
                System.out.println("Resposta Correta!");
                respostaCerta4 = true;

                String questao5 = "Qual o número mínimo de jogadores numa partida de futebol?";

            Collection<String> alternativas5 = new ArrayList<>();
            alternativas5.add("8");
            alternativas5.add("10");
            alternativas5.add("9");
            alternativas5.add("11");
            alternativas5.add("7");
    
            String alternativaCorreta5 = "7";
            String alternativaErradaA5 = "11";
            String alternativaErradaB5 = "9";
            String alternativaErradaC5 = "10";
            String alternativaErradaD5 = "8";
    
            boolean respostaCerta5 = false;
    
            do {
            System.out.println(questao5);
    
            //embaralhar as pergunta
            Collections.shuffle((List<String>) alternativas5);
    
            //mostra perguntas
            for(int i = 0; i < alternativas5.size(); i++) {
                System.out.println("[" + i + "]" + ((List<String>) alternativas5).get(i));
            }
    
            System.out.println("Digite sua resposta: ");
            String resposta5 = scanner.nextLine();
            int respostaInt5 = Integer.parseInt(resposta5);
    
            String valorDaResposta5 = ((List<String>) alternativas5).get(respostaInt5);
    
            if ( valorDaResposta5.equals(alternativaCorreta5)) {
                System.out.println("Resposta Correta!");
                respostaCerta5 = true;

                String questao6 = "Qual destes países é transcontinental";

            Collection<String> alternativas6 = new ArrayList<>();
            alternativas6.add("Rússia");
            alternativas6.add("Filipinas");
            alternativas6.add("Marrocos");
            alternativas6.add("Groenlândia");
            alternativas6.add("Tanzânia");
    
            String alternativaCorreta6 = "Rússia";
            String alternativaErradaA6 = "Filipinas";
            String alternativaErradaB6 = "Marrocos";
            String alternativaErradaC6 = "Groenlândia";
            String alternativaErradaD6 = "Tanzânia";
    
            boolean respostaCerta6 = false;
    
            do {
            System.out.println(questao6);
    
            //embaralhar as pergunta
            Collections.shuffle((List<String>) alternativas6);
    
            //mostra perguntas
            for(int i = 0; i < alternativas6.size(); i++) {
                System.out.println("[" + i + "]" + ((List<String>) alternativas6).get(i));
            }
    
            System.out.println("Digite sua resposta: ");
            String resposta6 = scanner.nextLine();
            int respostaInt6 = Integer.parseInt(resposta6);
    
            String valorDaResposta6 = ((List<String>) alternativas6).get(respostaInt6);
    
            if ( valorDaResposta6.equals(alternativaCorreta6)) {
                System.out.println("Resposta Correta!");
                respostaCerta6 = true;

                String questao7 = "Qual o maior animal terrestre?";

            Collection<String> alternativas7 = new ArrayList<>();
            alternativas7.add("Baleia Azul");
            alternativas7.add("Dinossauro");
            alternativas7.add("Elefante africano");
            alternativas7.add("Tubarão Branco");
            alternativas7.add("Girafa");
    
            String alternativaCorreta7 = "Elefante africano";
            String alternativaErradaA7 = "Baleia Azul";
            String alternativaErradaB7 = "Dinossauro";
            String alternativaErradaC7 = "Tubarão Branco";
            String alternativaErradaD7 = "Girafa";
    
            boolean respostaCerta7 = false;
    
            do {
            System.out.println(questao7);
    
            //embaralhar as pergunta
            Collections.shuffle((List<String>) alternativas7);
    
            //mostra perguntas
            for(int i = 0; i < alternativas7.size(); i++) {
                System.out.println("[" + i + "]" + ((List<String>) alternativas7).get(i));
            }
    
            System.out.println("Digite sua resposta: ");
            String resposta7 = scanner.nextLine();
            int respostaInt7 = Integer.parseInt(resposta7);
    
            String valorDaResposta7 = ((List<String>) alternativas7).get(respostaInt7);
    
            if ( valorDaResposta7.equals(alternativaCorreta7)) {
                System.out.println("Resposta Correta!");
                respostaCerta7 = true;

                String questao8 = "Quais os nomes dos três Reis Magos?";

            Collection<String> alternativas8 = new ArrayList<>();
            alternativas8.add("Gaspar, Nicolau e Natanael");
            alternativas8.add("Belchior, Gaspar e Baltazar");
            alternativas8.add("Belchior, Gaspar e Nataniel");
            alternativas8.add("Gabriel, Benjamim e Melchior");
            alternativas8.add("Melchior, Noé e Galileu");
    
            String alternativaCorreta8 = "Belchior, Gaspar e Baltazar";
            String alternativaErradaA8 = "Melchior, Noé e Galileu";
            String alternativaErradaB8 = "Gabriel, Benjamim e Melchior";
            String alternativaErradaC8 = "Belchior, Gaspar e Nataniel";
            String alternativaErradaD8 = "Gaspar, Nicolau e Natanael";
    
            boolean respostaCerta8 = false;
    
            do {
            System.out.println(questao8);
    
            //embaralhar as pergunta
            Collections.shuffle((List<String>) alternativas8);
    
            //mostra perguntas
            for(int i = 0; i < alternativas8.size(); i++) {
                System.out.println("[" + i + "]" + ((List<String>) alternativas8).get(i));
            }
    
            System.out.println("Digite sua resposta: ");
            String resposta8 = scanner.nextLine();
            int respostaInt8 = Integer.parseInt(resposta8);
    
            String valorDaResposta8 = ((List<String>) alternativas8).get(respostaInt8);
    
            if ( valorDaResposta8.equals(alternativaCorreta8)) {
                System.out.println("Resposta Correta!");
                respostaCerta8 = true;

                String questao9 = "Qual é o maior arquipélago da Terra?";

                Collection<String> alternativas9 = new ArrayList<>();
                alternativas9.add("A Indonésia");
                alternativas9.add("a Filipinas");
                alternativas9.add("as Bahamas");
                alternativas9.add("a Finlândia");
                alternativas9.add("as Maldivas");
        
                String alternativaCorreta9 = "A Indonésia";
                String alternativaErradaA9 = "a Filipinas";
                String alternativaErradaB9 = "as Bahamas";
                String alternativaErradaC9 = "a Finlândia";
                String alternativaErradaD9 = "as Maldivas";
        
                boolean respostaCerta9 = false;
        
                do {
                System.out.println(questao9);
        
                //embaralhar as pergunta
                Collections.shuffle((List<String>) alternativas9);
        
                //mostra perguntas
                for(int i = 0; i < alternativas9.size(); i++) {
                    System.out.println("[" + i + "]" + ((List<String>) alternativas9).get(i));
                }
        
                System.out.println("Digite sua resposta: ");
                String resposta9 = scanner.nextLine();
                int respostaInt9 = Integer.parseInt(resposta9);
        
                String valorDaResposta9 = ((List<String>) alternativas9).get(respostaInt9);
        
                if ( valorDaResposta9.equals(alternativaCorreta9)) {
                    System.out.println("Resposta Correta!");
                    respostaCerta9 = true;

                    String questao0 = "Qual é o maior arquipélago da Terra?";

                Collection<String> alternativas0 = new ArrayList<>();
                alternativas0.add("Oceano Índico");
                alternativas0.add("Oceano Antártico");
                alternativas0.add("Oceano Atlântico");
                alternativas0.add("Oceano Pacífico");
                alternativas0.add("Oceano Ártico");
        
                String alternativaCorreta0 = "Oceano Índico";
                String alternativaErradaA0 = "Oceano Antártico";
                String alternativaErradaB0 = "Oceano Atlântico";
                String alternativaErradaC0 = "Oceano Pacífico";
                String alternativaErradaD0 = "Oceano Ártico";
        
                boolean respostaCerta0 = false;
        
                do {
                System.out.println(questao0);
        
                //embaralhar as pergunta
                Collections.shuffle((List<String>) alternativas0);
        
                //mostra perguntas
                for(int i = 0; i < alternativas0.size(); i++) {
                    System.out.println("[" + i + "]" + ((List<String>) alternativas0).get(i));
                }
        
                System.out.println("Digite sua resposta: ");
                String resposta0 = scanner.nextLine();
                int respostaInt0 = Integer.parseInt(resposta0);
        
                String valorDaResposta0 = ((List<String>) alternativas0).get(respostaInt0);
        
                if ( valorDaResposta0.equals(alternativaCorreta0)) {
                    System.out.println("Resposta Correta!");
                    respostaCerta0 = true;
                } else {
                    System.out.println("Resposta errada! Tente acertar na proxima :)");
                    if (valorDaResposta0.equals(alternativaErradaA0)){
                        break;
                    }
                    if (valorDaResposta0.equals(alternativaErradaB0)){
                        break;
                    }
                    if (valorDaResposta0.equals(alternativaErradaC0)){
                        break;
                    }
                    if (valorDaResposta0.equals(alternativaErradaD0)){
                        break;
                    }
                } 
             } while (!respostaCerta0);
                } else {
                    System.out.println("Resposta errada! Tente acertar na proxima :)");
                    if (valorDaResposta9.equals(alternativaErradaA9)){
                        break;
                    }
                    if (valorDaResposta9.equals(alternativaErradaB9)){
                        break;
                    }
                    if (valorDaResposta9.equals(alternativaErradaC9)){
                        break;
                    }
                    if (valorDaResposta9.equals(alternativaErradaD9)){
                        break;
                    }
                } 
             } while (!respostaCerta9);
            } else {
                System.out.println("Resposta errada! Tente acertar na proxima :)");
                if (valorDaResposta8.equals(alternativaErradaA8)){
                    break;
                }
                if (valorDaResposta8.equals(alternativaErradaB8)){
                    break;
                }
                if (valorDaResposta8.equals(alternativaErradaC8)){
                    break;
                }
                if (valorDaResposta8.equals(alternativaErradaD8)){
                    break;
                }
            } 
         } while (!respostaCerta8);
            } else {
                System.out.println("Resposta errada! Tente acertar na proxima :)");
                if (valorDaResposta7.equals(alternativaErradaA7)){
                    break;
                }
                if (valorDaResposta7.equals(alternativaErradaB7)){
                    break;
                }
                if (valorDaResposta7.equals(alternativaErradaC7)){
                    break;
                }
                if (valorDaResposta7.equals(alternativaErradaD7)){
                    break;
                }
            } 
         } while (!respostaCerta7);
            } else {
                System.out.println("Resposta errada! Tente acertar na proxima :)");
                if (valorDaResposta6.equals(alternativaErradaA6)){
                    break;
                }
                if (valorDaResposta6.equals(alternativaErradaB6)){
                    break;
                }
                if (valorDaResposta6.equals(alternativaErradaC6)){
                    break;
                }
                if (valorDaResposta6.equals(alternativaErradaD6)){
                    break;
                }
            } 
         } while (!respostaCerta6);
            } else {
                System.out.println("Resposta errada! Tente acertar na proxima :)");
                if (valorDaResposta5.equals(alternativaErradaA5)){
                    break;
                }
                if (valorDaResposta5.equals(alternativaErradaB5)){
                    break;
                }
                if (valorDaResposta5.equals(alternativaErradaC5)){
                    break;
                }
                if (valorDaResposta5.equals(alternativaErradaD5)){
                    break;
                }
            } 
         } while (!respostaCerta5);
            } else {
                System.out.println("Resposta errada! Tente acertar na proxima :)");
                if (valorDaResposta4.equals(alternativaErradaA4)){
                    break;
                }
                if (valorDaResposta4.equals(alternativaErradaB4)){
                    break;
                }
                if (valorDaResposta4.equals(alternativaErradaC4)){
                    break;
                }
                if (valorDaResposta4.equals(alternativaErradaD4)){
                    break;
                }
            } 
         } while (!respostaCerta4);
            } else {
                System.out.println("Resposta errada! Tente acertar na proxima :)");
                if (valorDaResposta3.equals(alternativaErradaA3)){
                    break;
                }
                if (valorDaResposta3.equals(alternativaErradaB3)){
                    break;
                }
                if (valorDaResposta3.equals(alternativaErradaC3)){
                    break;
                }
                if (valorDaResposta3.equals(alternativaErradaD3)){
                    break;
                }
            } 
         } while (!respostaCerta3);
            } else {
                System.out.println("Resposta errada! Tente acertar na proxima :)");
                if (valorDaResposta2.equals(alternativaErradaA2)){
                    break;
                }
                if (valorDaResposta2.equals(alternativaErradaB2)){
                    break;
                }
                if (valorDaResposta2.equals(alternativaErradaC2)){
                    break;
                }
                if (valorDaResposta2.equals(alternativaErradaD2)){
                    break;
                }
            } 
         } while (!respostaCerta2);
        } else {
            System.out.println("Resposta errada! Tente acertar na proxima :)");
            if (valorDaResposta.equals(alternativaErradaA)){
                break;
            }
            if (valorDaResposta.equals(alternativaErradaB)){
                break;
            }
            if (valorDaResposta.equals(alternativaErradaC)){
                break;
            }
            if (valorDaResposta.equals(alternativaErradaD)){
                break;
            }
            
        } 
    scanner.close();
    } while (!respostaCerta);

    }

    public void setVisible(boolean b) {
    }
}