import java.util.Scanner;

public class teste {
    public static void main (String[] args){
            Scanner a1 = new Scanner(System.in);
            System.out.println("Digite 's' para iniciar:");
            String pgt = a1.nextLine();


            while(pgt!=("eua")){
                String pgt2 = a1.nextLine();
                if(pgt2.equals("eae")){
                    System.out.println("Eae");
                }
                if(pgt2.equals("salve")){
                    System.out.println("Salve");
                }
                if(pgt2.equals("flw")){
                    System.out.println("Tchau!");
                    break;
                }
            }

            a1.close();
    }
}
